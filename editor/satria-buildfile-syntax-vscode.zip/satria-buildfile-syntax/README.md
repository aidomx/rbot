# Satria Buildfile syntax (VS Code)

Highlight `Buildfile`, `Buildfile.ws`, and `*.satria-build` using the grammar from Satria v0.2.3.109 examples and design docs.

Supports `use workspace`, aliases (`projects.rupa as rupa`), dotted keys, assignments, comments (`#`, `//`), quoted strings, booleans, placeholders, and legacy section headers.

## Install

Copy this directory to `~/.vscode/extensions/satria-buildfile-syntax-0.1.0` (or `~/.vscode-server/extensions/` for remote VS Code) and reload VS Code.

This is highlighting only: no parser, validation, completion, or diagnostics. Grammar is deliberately permissive for paths and unquoted values.
