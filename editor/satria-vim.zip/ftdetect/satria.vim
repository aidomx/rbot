augroup satria_buildfile_detection
  autocmd!
  autocmd BufRead,BufNewFile Buildfile,Buildfile.ws setfiletype satria
augroup END
