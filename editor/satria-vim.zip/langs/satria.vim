" ---------------------------
" satria Development
" ---------------------------

" satria specific settings
autocmd FileType satria setlocal shiftwidth=2 tabstop=2
autocmd FileType satria setlocal commentstring=//\ %s

augroup satria_filetype
    autocmd!
    autocmd BufRead,BufNewFile Buildfile setfiletype satria
    autocmd BufRead,BufNewFile *.ws setfiletype satria
augroup END
