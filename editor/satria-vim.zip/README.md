# Satria Buildfile syntax for Vim

Supports `Buildfile` and `Buildfile.ws`: `use workspace`, aliases with `as`, dotted keys, assignments, comments, booleans, strings, and `{name}` placeholders.

## Install (Vim 8+)

Copy the `syntax/` and `ftdetect/` directories into `~/.vim/`:

```sh
mkdir -p ~/.vim/syntax ~/.vim/ftdetect
cp syntax/satria.vim ~/.vim/syntax/
cp ftdetect/satria.vim ~/.vim/ftdetect/
```

Enable syntax in `~/.vimrc` if not already enabled:

```vim
syntax on
filetype on
```

Open `Buildfile` or `Buildfile.ws` and verify with `:set filetype?` (should say `satria`).
