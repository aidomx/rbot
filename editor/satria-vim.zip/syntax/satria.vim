" Vim syntax for Satria Buildfile / Buildfile.ws
if exists('b:current_syntax')
  finish
endif

syn case match
syn match satriaComment /#.*/ contains=satriaTodo
syn match satriaComment /\/\/.*/ contains=satriaTodo
syn keyword satriaTodo TODO FIXME NOTE XXX contained
syn region satriaString start=/"/ skip=/\\"/ end=/"/ contains=satriaPlaceholder
syn region satriaString start=/'/ skip=/\\'/ end=/'/ contains=satriaPlaceholder
syn match satriaPlaceholder /{[A-Za-z_][A-Za-z0-9_.-]*}/ containedin=satriaString,satriaValue
syn match satriaDirective /^\s*use\s\+\%(workspace\|alias\)\>/ contains=satriaUseKeyword,satriaUseMode
syn match satriaUseKeyword /^\s*use\>/ contained
syn keyword satriaUseMode workspace alias contained
syn match satriaAlias /^\s*[A-Za-z_][A-Za-z0-9_.-]*\s\+as\s\+[A-Za-z_][A-Za-z0-9_-]*\s*$/ contains=satriaAliasKeyword,satriaAliasName,satriaKey
syn match satriaAliasKeyword /\<as\>/ contained
syn match satriaAliasName /\<as\s\+\zs[A-Za-z_][A-Za-z0-9_-]*/ contained
syn match satriaKey /^\s*\zs[A-Za-z_][A-Za-z0-9_.-]*\ze\s*=/
syn match satriaAssign /=/ containedin=satriaValueLine
syn match satriaValueLine /^\s*[A-Za-z_][A-Za-z0-9_.-]*\s*=.*$/ contains=satriaKey,satriaAssign,satriaString,satriaComment,satriaBool,satriaNumber,satriaPlaceholder,satriaComma
syn keyword satriaBool true false auto always never contained
syn match satriaNumber /\<\d\+\%(.\d\+\)*\>/ contained
syn match satriaComma /,/ contained
syn match satriaSection /^\s*[A-Za-z_][A-Za-z0-9_.-]*\s*:\s*$/

hi def link satriaComment Comment
hi def link satriaTodo Todo
hi def link satriaString String
hi def link satriaPlaceholder Special
hi def link satriaUseKeyword Keyword
hi def link satriaUseMode Type
hi def link satriaAliasKeyword Keyword
hi def link satriaAliasName Identifier
hi def link satriaKey Identifier
hi def link satriaAssign Operator
hi def link satriaBool Boolean
hi def link satriaNumber Number
hi def link satriaComma Delimiter
hi def link satriaSection Statement
let b:current_syntax = 'satria'
